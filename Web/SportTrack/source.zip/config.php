<?php
const DB_FILE = __ROOT__.'db/sport_track.db';
const VIEWS_DIR = __ROOT__.'/views';
const CONTROLLERS_DIR = __ROOT__.'/controllers';
?>