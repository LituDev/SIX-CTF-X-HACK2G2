<?php

include __ROOT__ . "/views/header.php";

?>
<h1>On est Théo CHALLON et François BOISSEL</h1>
<?php

include __ROOT__ . "/views/footer.html";
?>
