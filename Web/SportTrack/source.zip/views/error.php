<?php
// header
include __ROOT__ . "/views/header.php";

echo $data['message'];

include __ROOT__ . "/views/footer.html";
?>
