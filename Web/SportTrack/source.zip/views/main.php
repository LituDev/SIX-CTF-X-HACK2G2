<?php include __ROOT__ . "/views/header.php"; ?>

<div class="form">
    <h1>Bienvenue</h1>
</div>
            
<?php include __ROOT__ . "/views/footer.html"; ?>
