<?php

include __ROOT__ . "/views/header.php";

echo "Lastname =". $data['lastname'];
echo "<br>";
echo "Firstname =". $data['firstname'];

include __ROOT__ . "/views/footer.html";
?>
