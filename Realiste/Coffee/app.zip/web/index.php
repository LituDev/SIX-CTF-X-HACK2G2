<?php
header("Location: /compiler.php");
?>